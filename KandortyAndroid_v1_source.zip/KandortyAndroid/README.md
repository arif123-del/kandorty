# Kandorty Android v1.1 — Website-style native design

Package: `online.kandorty.app`

This build keeps the existing Firebase/Firestore/Authentication integration and redesigns the native Android UI to visually match the Kandorty website more closely.

Included in v1.1:
- Kandorty logo and custom app icon
- Red / white / wine brand palette based on the website
- UAE delivery announcement bar
- Website-style account, favorites, tracking and cart controls
- Hero section and store share button
- Category filters: all, women, girls, cotton, silk
- Two-column product grid
- Product cards with favorites, sale price, stock/sold-out label, details and add-to-cart
- Website-style product details, cart, checkout, tracking and phone-login screens
- Favorites stored locally on the phone
- Existing Firebase product/order/login logic preserved

Build command:
`gradle --no-daemon assembleDebug`

APK output:
`app/build/outputs/apk/debug/app-debug.apk`
