# Kandorty Android

Native Android starter app for `online.kandorty.app`, connected to the existing Kandorty Firebase project.

Included in v1 starter:
- Firestore products (`products`) with live updates
- Product details
- Cart with stock limits
- Guest checkout
- Firestore order creation (`orders`) with stock decrement transaction
- Tracking (`tracking`)
- Optional Firebase phone login
- Native Android share sheet
- Sold-out behavior when stock reaches 0
- Admin intentionally excluded from the customer app

## Firebase
`app/google-services.json` is already included from the Firebase Android registration.

## Important next step for Phone Auth
Build/sign the app, then add the app's SHA-1 and SHA-256 fingerprints in Firebase Console > Project settings > Your apps > Kandorty Android. Phone Auth may not work reliably until these fingerprints are added.

## Build
Open this folder in Android Studio and let Gradle sync. Then Build > Generate App Bundles or APKs.

## Notes
The existing website stores products in Firestore with fields such as `code`, `nameAr`, `price`, `salePrice`, `stock`, `description`, `active`, and `images`; this app reads the same schema.
