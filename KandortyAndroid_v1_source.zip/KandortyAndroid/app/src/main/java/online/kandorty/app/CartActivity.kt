package online.kandorty.app

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CartActivity:AppCompatActivity(){
    private lateinit var adapter:CartAdapter
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState);setContentView(R.layout.activity_cart); adapter=CartAdapter(emptyList()){id,d->CartStore.change(this,id,d);refresh()}; findViewById<RecyclerView>(R.id.cartRecycler).apply{layoutManager=LinearLayoutManager(this@CartActivity);adapter=this@CartActivity.adapter}; findViewById<Button>(R.id.checkoutBtn).setOnClickListener{if(CartStore.all(this).isNotEmpty())startActivity(Intent(this,CheckoutActivity::class.java))};refresh() }
    override fun onResume(){super.onResume();refresh()}
    private fun refresh(){adapter.update(CartStore.all(this));findViewById<TextView>(R.id.totalText).text="الإجمالي: ${"%.2f".format(CartStore.total(this))} AED";findViewById<Button>(R.id.checkoutBtn).isEnabled=CartStore.all(this).isNotEmpty()}
}
