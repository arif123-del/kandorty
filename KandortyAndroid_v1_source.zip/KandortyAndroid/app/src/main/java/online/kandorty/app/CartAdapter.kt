package online.kandorty.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class CartAdapter(private var items:List<CartEntry>, private val onChange:(String,Int)->Unit):RecyclerView.Adapter<CartAdapter.VH>(){
    class VH(v:View):RecyclerView.ViewHolder(v){
        val image:ImageView=v.findViewById(R.id.image); val name:TextView=v.findViewById(R.id.name); val price:TextView=v.findViewById(R.id.price); val qty:TextView=v.findViewById(R.id.qty); val minus:Button=v.findViewById(R.id.minus); val plus:Button=v.findViewById(R.id.plus)
    }
    override fun onCreateViewHolder(p:ViewGroup,t:Int)=VH(LayoutInflater.from(p.context).inflate(R.layout.item_cart,p,false))
    override fun getItemCount()=items.size
    override fun onBindViewHolder(h:VH,pos:Int){ val e=items[pos]; h.name.text=e.product.nameAr; h.price.text="${e.product.effectivePrice()} AED"; h.qty.text=e.qty.toString(); Glide.with(h.image).load(e.product.images.firstOrNull()).centerCrop().into(h.image); h.minus.setOnClickListener{onChange(e.product.id,-1)}; h.plus.setOnClickListener{onChange(e.product.id,1)} }
    fun update(v:List<CartEntry>){items=v;notifyDataSetChanged()}
}
