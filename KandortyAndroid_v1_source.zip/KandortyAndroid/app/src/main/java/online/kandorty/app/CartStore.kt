package online.kandorty.app

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object CartStore {
    private const val PREF = "kandorty_cart"
    private const val KEY = "items"
    private val gson = Gson()
    private val items = linkedMapOf<String, CartEntry>()

    fun load(context: Context) {
        if (items.isNotEmpty()) return
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null) ?: return
        runCatching {
            val type = object : TypeToken<List<CartEntry>>() {}.type
            val list: List<CartEntry> = gson.fromJson(raw, type)
            list.forEach { items[it.product.id] = it }
        }
    }

    fun all(context: Context): List<CartEntry> { load(context); return items.values.toList() }
    fun count(context: Context): Int = all(context).sumOf { it.qty }
    fun total(context: Context): Double = all(context).sumOf { it.product.effectivePrice() * it.qty }

    fun add(context: Context, p: Product): Boolean {
        load(context)
        if (p.isSoldOut()) return false
        val e = items[p.id]
        val next = (e?.qty ?: 0) + 1
        if (p.stock != null && next > p.stock!!) return false
        if (e == null) items[p.id] = CartEntry(p, 1) else e.qty = next
        save(context); return true
    }

    fun change(context: Context, id: String, delta: Int) {
        load(context)
        val e = items[id] ?: return
        var next = e.qty + delta
        e.product.stock?.let { if (next > it) next = it.toInt() }
        if (next <= 0) items.remove(id) else e.qty = next
        save(context)
    }

    fun clear(context: Context) { items.clear(); save(context) }
    private fun save(context: Context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, gson.toJson(items.values.toList())).apply()
    }
}
