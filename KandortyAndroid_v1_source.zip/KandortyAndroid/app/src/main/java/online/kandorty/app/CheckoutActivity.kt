package online.kandorty.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.time.Instant

class CheckoutActivity:AppCompatActivity(){
    private val db by lazy{FirebaseFirestore.getInstance()}
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState);setContentView(R.layout.activity_checkout)
        val cities=listOf("دبي","أبوظبي","الشارقة","عجمان","أم القيوين","رأس الخيمة","الفجيرة")
        findViewById<Spinner>(R.id.citySpinner).adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,cities)
        val pays=listOf("الدفع عند الاستلام","تحويل/اتفاق مع المتجر")
        findViewById<Spinner>(R.id.paymentSpinner).adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,pays)
        FirebaseAuth.getInstance().currentUser?.phoneNumber?.let{findViewById<EditText>(R.id.phoneInput).setText(it)}
        findViewById<TextView>(R.id.totalText).text="الإجمالي: ${"%.2f".format(CartStore.total(this))} AED"
        findViewById<Button>(R.id.submitBtn).setOnClickListener{submit()}
    }
    private fun submit(){
        val rows=CartStore.all(this);if(rows.isEmpty())return
        val name=findViewById<EditText>(R.id.nameInput).text.toString().trim(); val phone=findViewById<EditText>(R.id.phoneInput).text.toString().trim(); val location=findViewById<EditText>(R.id.locationInput).text.toString().trim()
        if(name.isBlank()||phone.isBlank()||location.isBlank()){Toast.makeText(this,"أكملي الاسم والهاتف والعنوان",Toast.LENGTH_SHORT).show();return}
        val btn=findViewById<Button>(R.id.submitBtn);btn.isEnabled=false
        lifecycleScope.launch {
            try{
                val id="KD-"+System.currentTimeMillis().toString().takeLast(8)
                val user=FirebaseAuth.getInstance().currentUser
                val items=rows.map{mapOf("id" to it.product.id,"code" to it.product.code,"name" to it.product.nameAr,"price" to it.product.effectivePrice(),"qty" to it.qty)}
                val order=hashMapOf<String,Any>("id" to id,"createdAt" to Instant.now().toString(),"status" to "new","total" to CartStore.total(this@CheckoutActivity),"payment" to findViewById<Spinner>(R.id.paymentSpinner).selectedItem.toString(),"notes" to findViewById<EditText>(R.id.notesInput).text.toString().trim(),"customer" to mapOf("name" to name,"phone" to phone,"city" to findViewById<Spinner>(R.id.citySpinner).selectedItem.toString(),"location" to location),"items" to items)
                user?.let{order["customerUid"]=it.uid; it.phoneNumber?.let{p->order["authPhone"]=p}}
                db.runTransaction { tx ->
                    rows.forEach { e ->
                        val ref=db.collection("products").document(e.product.id); val snap=tx.get(ref); val raw=snap.get("stock")
                        if(raw is Number){ val current=raw.toLong(); if(current<e.qty) throw IllegalStateException("الكمية غير متوفرة: ${e.product.nameAr}"); tx.update(ref,mapOf("stock" to current-e.qty,"updatedAt" to Instant.now().toString())) }
                    }
                    tx.set(db.collection("orders").document(id),order)
                }.await()
                db.collection("tracking").document(id).set(mapOf("id" to id,"status" to "new","createdAt" to order["createdAt"]!!)).await()
                CartStore.clear(this@CheckoutActivity)
                Toast.makeText(this@CheckoutActivity,"تم الطلب بنجاح. رقم الطلب: $id",Toast.LENGTH_LONG).show(); finish()
            }catch(e:Exception){Toast.makeText(this@CheckoutActivity,"لم يتم الطلب: ${e.message}",Toast.LENGTH_LONG).show();btn.isEnabled=true}
        }
    }
}
