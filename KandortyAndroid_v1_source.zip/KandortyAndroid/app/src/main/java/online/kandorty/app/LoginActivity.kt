package online.kandorty.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseException
import com.google.firebase.auth.*
import java.util.concurrent.TimeUnit

class LoginActivity:AppCompatActivity(){
    private val auth by lazy{FirebaseAuth.getInstance()}; private var verificationId:String?=null
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContentView(R.layout.activity_login);auth.currentUser?.phoneNumber?.let{findViewById<TextView>(R.id.statusText).text="مسجل: $it"};findViewById<Button>(R.id.sendCodeBtn).setOnClickListener{sendCode()};findViewById<Button>(R.id.verifyBtn).setOnClickListener{verify()}}
    private fun sendCode(){val phone=findViewById<EditText>(R.id.phoneInput).text.toString().trim();if(!phone.startsWith("+")){toast("اكتبي الرقم مع رمز الدولة، مثال +971...");return};findViewById<TextView>(R.id.statusText).text="جارٍ إرسال الرمز...";val opts=PhoneAuthOptions.newBuilder(auth).setPhoneNumber(phone).setTimeout(60L,TimeUnit.SECONDS).setActivity(this).setCallbacks(object:PhoneAuthProvider.OnVerificationStateChangedCallbacks(){override fun onVerificationCompleted(c:PhoneAuthCredential){auth.signInWithCredential(c).addOnSuccessListener{toast("تم تسجيل الدخول");finish()}};override fun onVerificationFailed(e:FirebaseException){findViewById<TextView>(R.id.statusText).text="فشل: ${e.message}"};override fun onCodeSent(id:String,t:PhoneAuthProvider.ForceResendingToken){verificationId=id;findViewById<TextView>(R.id.statusText).text="تم إرسال الرمز"}}).build();PhoneAuthProvider.verifyPhoneNumber(opts)}
    private fun verify(){val id=verificationId?:return toast("أرسلي الرمز أولاً");val code=findViewById<EditText>(R.id.codeInput).text.toString().trim();if(code.length<6)return toast("أدخلي رمز التحقق");auth.signInWithCredential(PhoneAuthProvider.getCredential(id,code)).addOnSuccessListener{toast("تم تسجيل الدخول");finish()}.addOnFailureListener{toast("الرمز غير صحيح أو انتهت صلاحيته")}}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
