package online.kandorty.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : AppCompatActivity() {
    private val db by lazy { FirebaseFirestore.getInstance() }
    private lateinit var adapter: ProductAdapter
    private var products = listOf<Product>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        CartStore.load(this)
        val recycler=findViewById<RecyclerView>(R.id.productsRecycler)
        adapter=ProductAdapter(emptyList(), { openProduct(it) }, { addProduct(it) })
        recycler.layoutManager=LinearLayoutManager(this); recycler.adapter=adapter
        findViewById<EditText>(R.id.searchInput).doAfterTextChanged { filter(it?.toString().orEmpty()) }
        findViewById<Button>(R.id.cartBtn).setOnClickListener { startActivity(Intent(this,CartActivity::class.java)) }
        findViewById<Button>(R.id.trackingBtn).setOnClickListener { startActivity(Intent(this,TrackingActivity::class.java)) }
        findViewById<Button>(R.id.loginBtn).setOnClickListener { startActivity(Intent(this,LoginActivity::class.java)) }
        findViewById<Button>(R.id.shareBtn).setOnClickListener {
            val share=Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT,"https://kandorty.online") }
            startActivity(Intent.createChooser(share,"مشاركة Kandorty"))
        }
        listenProducts()
    }

    private fun listenProducts() {
        db.collection("products").addSnapshotListener { snap, err ->
            findViewById<View>(R.id.loading).visibility=View.GONE
            if(err!=null){ Toast.makeText(this,"تعذر تحميل المنتجات",Toast.LENGTH_LONG).show(); return@addSnapshotListener }
            products=snap?.documents?.mapNotNull { d -> d.toObject(Product::class.java)?.apply { id=d.id } }?.filter { it.active } ?: emptyList()
            filter(findViewById<EditText>(R.id.searchInput).text.toString())
        }
    }
    private fun filter(q0:String){
        val q=q0.trim().lowercase()
        val list=products.filter { q.isBlank() || (it.code+" "+it.nameAr).lowercase().contains(q) }
        adapter.update(list); findViewById<View>(R.id.emptyText).visibility=if(list.isEmpty()) View.VISIBLE else View.GONE
    }
    private fun openProduct(p:Product){ startActivity(Intent(this,ProductDetailActivity::class.java).putExtra("id",p.id)) }
    private fun addProduct(p:Product){
        val ok=CartStore.add(this,p)
        Toast.makeText(this,if(ok) "تمت الإضافة للسلة" else "الكمية المطلوبة غير متوفرة",Toast.LENGTH_SHORT).show()
    }
}
