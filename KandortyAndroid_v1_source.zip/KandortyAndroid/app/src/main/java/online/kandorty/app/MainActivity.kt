package online.kandorty.app

import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : AppCompatActivity() {
    private val db by lazy { FirebaseFirestore.getInstance() }
    private lateinit var adapter: ProductAdapter
    private var products = listOf<Product>()
    private var selectedCategory = "all"
    private var favoritesOnly = false
    private lateinit var categoryButtons: Map<String, MaterialButton>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        CartStore.load(this)

        val recycler = findViewById<RecyclerView>(R.id.productsRecycler)
        adapter = ProductAdapter(
            emptyList(),
            { openProduct(it) },
            { addProduct(it) },
            { toggleFavorite(it) },
            { WishlistStore.contains(this, it.id) }
        )
        recycler.layoutManager = GridLayoutManager(this, 2)
        recycler.adapter = adapter

        findViewById<EditText>(R.id.searchInput).doAfterTextChanged { filter() }
        findViewById<Button>(R.id.cartBtn).setOnClickListener { startActivity(Intent(this, CartActivity::class.java)) }
        findViewById<Button>(R.id.trackingBtn).setOnClickListener { startActivity(Intent(this, TrackingActivity::class.java)) }
        findViewById<Button>(R.id.loginBtn).setOnClickListener { startActivity(Intent(this, LoginActivity::class.java)) }
        findViewById<Button>(R.id.wishlistBtn).setOnClickListener {
            favoritesOnly = !favoritesOnly
            selectedCategory = "all"
            updateCategoryStyle()
            updateWishlistButton()
            filter()
        }
        findViewById<Button>(R.id.shareBtn).setOnClickListener {
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "تفضلي رابط متجر Kandorty\nhttps://kandorty.online")
            }
            startActivity(Intent.createChooser(share, "مشاركة Kandorty"))
        }

        categoryButtons = mapOf(
            "all" to findViewById(R.id.catAll),
            "women" to findViewById(R.id.catWomen),
            "girls" to findViewById(R.id.catGirls),
            "cotton" to findViewById(R.id.catCotton),
            "silk" to findViewById(R.id.catSilk)
        )
        categoryButtons.forEach { (cat, btn) ->
            btn.setOnClickListener {
                selectedCategory = cat
                favoritesOnly = false
                updateCategoryStyle()
                updateWishlistButton()
                filter()
            }
        }
        updateCategoryStyle()
        listenProducts()
    }

    override fun onResume() {
        super.onResume()
        updateTopCounts()
        if (::adapter.isInitialized) adapter.refreshFavorites()
    }

    private fun listenProducts() {
        db.collection("products").addSnapshotListener { snap, err ->
            findViewById<View>(R.id.loading).visibility = View.GONE
            if (err != null) {
                Toast.makeText(this, "تعذر تحميل المنتجات", Toast.LENGTH_LONG).show()
                return@addSnapshotListener
            }
            products = snap?.documents?.mapNotNull { d ->
                d.toObject(Product::class.java)?.apply { id = d.id }
            }?.filter { it.active } ?: emptyList()
            filter()
        }
    }

    private fun filter() {
        val q = findViewById<EditText>(R.id.searchInput).text.toString().trim().lowercase()
        val favIds = WishlistStore.ids(this)
        val list = products.filter { p ->
            val matchesSearch = q.isBlank() || (p.code + " " + p.nameAr).lowercase().contains(q)
            val matchesCategory = selectedCategory == "all" || p.category == selectedCategory
            val matchesFavorite = !favoritesOnly || favIds.contains(p.id)
            matchesSearch && matchesCategory && matchesFavorite
        }
        adapter.update(list)
        findViewById<View>(R.id.emptyText).visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        findViewById<TextView>(R.id.shopTitle).text = if (favoritesOnly) "المفضلة" else "تسوقي المخاوير"
    }

    private fun updateCategoryStyle() {
        if (!::categoryButtons.isInitialized) return
        val red = ContextCompat.getColor(this, R.color.kandorty_red)
        val white = ContextCompat.getColor(this, R.color.white)
        val dark = ContextCompat.getColor(this, R.color.kandorty_dark)
        val line = ContextCompat.getColor(this, R.color.line)
        categoryButtons.forEach { (cat, btn) ->
            val active = !favoritesOnly && cat == selectedCategory
            btn.backgroundTintList = ColorStateList.valueOf(if (active) red else white)
            btn.setTextColor(if (active) white else dark)
            btn.strokeColor = ColorStateList.valueOf(if (active) red else line)
            btn.strokeWidth = 1
        }
    }

    private fun updateWishlistButton() {
        val btn = findViewById<Button>(R.id.wishlistBtn)
        val count = WishlistStore.count(this)
        btn.text = if (favoritesOnly) "♥\nالمفضلة $count" else "❤\nالمفضلة $count"
        updateCategoryStyle()
    }

    private fun updateTopCounts() {
        findViewById<Button>(R.id.cartBtn).text = "🛒\nالسلة ${CartStore.count(this)}"
        updateWishlistButton()
    }

    private fun openProduct(p: Product) {
        startActivity(Intent(this, ProductDetailActivity::class.java).putExtra("id", p.id))
    }

    private fun addProduct(p: Product) {
        val ok = CartStore.add(this, p)
        Toast.makeText(this, if (ok) "تمت الإضافة للسلة" else "الكمية المطلوبة غير متوفرة", Toast.LENGTH_SHORT).show()
        updateTopCounts()
    }

    private fun toggleFavorite(p: Product) {
        val added = WishlistStore.toggle(this, p.id)
        Toast.makeText(this, if (added) "أضيف إلى المفضلة" else "أزيل من المفضلة", Toast.LENGTH_SHORT).show()
        adapter.refreshFavorites()
        updateTopCounts()
        if (favoritesOnly) filter()
    }
}
