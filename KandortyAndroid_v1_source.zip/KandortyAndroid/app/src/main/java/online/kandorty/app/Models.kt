package online.kandorty.app

data class Product(
    var id: String = "",
    var code: String = "",
    var nameAr: String = "",
    var category: String = "",
    var price: Double = 0.0,
    var salePrice: Double = 0.0,
    var stock: Long? = null,
    var description: String = "",
    var isNew: Boolean = false,
    var active: Boolean = true,
    var images: List<String> = emptyList()
) {
    fun effectivePrice(): Double = if (salePrice > 0) salePrice else price
    fun isSoldOut(): Boolean = stock != null && stock!! <= 0
}

data class CartEntry(var product: Product, var qty: Int)
