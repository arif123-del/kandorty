package online.kandorty.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class ProductAdapter(
    private var items: List<Product>,
    private val onOpen: (Product) -> Unit,
    private val onAdd: (Product) -> Unit
) : RecyclerView.Adapter<ProductAdapter.VH>() {
    class VH(v: View): RecyclerView.ViewHolder(v) {
        val image: ImageView = v.findViewById(R.id.productImage)
        val sold: TextView = v.findViewById(R.id.soldOutBadge)
        val name: TextView = v.findViewById(R.id.nameText)
        val code: TextView = v.findViewById(R.id.codeText)
        val price: TextView = v.findViewById(R.id.priceText)
        val stock: TextView = v.findViewById(R.id.stockText)
        val add: Button = v.findViewById(R.id.addBtn)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(LayoutInflater.from(parent.context).inflate(R.layout.item_product,parent,false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, pos: Int) {
        val p=items[pos]
        h.name.text=p.nameAr; h.code.text=p.code
        h.price.text="${p.effectivePrice()} AED"
        h.stock.text=p.stock?.let { "المتوفر: $it" } ?: ""
        h.sold.visibility=if(p.isSoldOut()) View.VISIBLE else View.GONE
        h.add.isEnabled=!p.isSoldOut(); h.add.text=if(p.isSoldOut()) "نفد المنتج" else "أضيفي للسلة"
        Glide.with(h.image).load(p.images.firstOrNull()).centerCrop().into(h.image)
        h.image.setOnClickListener { onOpen(p) }; h.itemView.setOnClickListener { onOpen(p) }
        h.add.setOnClickListener { onAdd(p) }
    }
    fun update(newItems: List<Product>) { items=newItems; notifyDataSetChanged() }
}
