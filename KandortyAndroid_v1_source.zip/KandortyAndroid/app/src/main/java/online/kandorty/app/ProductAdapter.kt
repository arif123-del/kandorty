package online.kandorty.app

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class ProductAdapter(
    private var items: List<Product>,
    private val onOpen: (Product) -> Unit,
    private val onAdd: (Product) -> Unit,
    private val onFavorite: (Product) -> Unit,
    private val isFavorite: (Product) -> Boolean
) : RecyclerView.Adapter<ProductAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image: ImageView = v.findViewById(R.id.productImage)
        val sold: TextView = v.findViewById(R.id.soldOutBadge)
        val fav: TextView = v.findViewById(R.id.favBtn)
        val name: TextView = v.findViewById(R.id.nameText)
        val code: TextView = v.findViewById(R.id.codeText)
        val price: TextView = v.findViewById(R.id.priceText)
        val oldPrice: TextView = v.findViewById(R.id.oldPriceText)
        val stock: TextView = v.findViewById(R.id.stockText)
        val add: Button = v.findViewById(R.id.addBtn)
        val details: Button = v.findViewById(R.id.detailsBtn)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_product, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val p = items[pos]
        h.name.text = p.nameAr
        h.code.text = p.code
        h.price.text = "${money(p.effectivePrice())} AED"
        if (p.salePrice > 0 && p.price > p.salePrice) {
            h.oldPrice.visibility = View.VISIBLE
            h.oldPrice.text = "${money(p.price)} AED"
            h.oldPrice.paintFlags = h.oldPrice.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        } else {
            h.oldPrice.visibility = View.GONE
        }
        h.stock.text = p.stock?.let { if (it > 0) "المتوفر: $it" else "نفد المنتج" } ?: ""
        h.sold.visibility = if (p.isSoldOut()) View.VISIBLE else View.GONE
        h.add.isEnabled = !p.isSoldOut()
        h.add.alpha = if (p.isSoldOut()) 0.5f else 1f
        h.add.text = if (p.isSoldOut()) "نفد المنتج" else "أضيفي للسلة"
        h.fav.text = if (isFavorite(p)) "♥" else "♡"

        Glide.with(h.image)
            .load(p.images.firstOrNull())
            .centerCrop()
            .into(h.image)

        h.image.setOnClickListener { onOpen(p) }
        h.details.setOnClickListener { onOpen(p) }
        h.add.setOnClickListener { onAdd(p) }
        h.fav.setOnClickListener { onFavorite(p) }
    }

    fun update(newItems: List<Product>) {
        items = newItems
        notifyDataSetChanged()
    }

    fun refreshFavorites() = notifyDataSetChanged()

    private fun money(value: Double): String =
        if (value % 1.0 == 0.0) value.toLong().toString() else String.format("%.2f", value)
}
