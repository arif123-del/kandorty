package online.kandorty.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.firebase.firestore.FirebaseFirestore

class ProductDetailActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_product_detail)
        val id=intent.getStringExtra("id") ?: return finish()
        FirebaseFirestore.getInstance().collection("products").document(id).get().addOnSuccessListener { d ->
            val p=d.toObject(Product::class.java)?.apply { this.id=d.id } ?: return@addOnSuccessListener
            findViewById<TextView>(R.id.name).text=p.nameAr
            findViewById<TextView>(R.id.code).text=p.code
            findViewById<TextView>(R.id.price).text="${p.effectivePrice()} AED"
            findViewById<TextView>(R.id.stock).text=p.stock?.let { "المتوفر: $it" } ?: ""
            findViewById<TextView>(R.id.description).text=p.description
            Glide.with(this).load(p.images.firstOrNull()).centerCrop().into(findViewById(R.id.image))
            findViewById<Button>(R.id.addBtn).apply {
                isEnabled=!p.isSoldOut(); text=if(p.isSoldOut()) "نفد المنتج" else "أضيفي للسلة"
                setOnClickListener { Toast.makeText(this@ProductDetailActivity, if(CartStore.add(this@ProductDetailActivity,p)) "تمت الإضافة" else "الكمية غير متوفرة", Toast.LENGTH_SHORT).show() }
            }
        }
    }
}
