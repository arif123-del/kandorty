package online.kandorty.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

class TrackingActivity:AppCompatActivity(){
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContentView(R.layout.activity_tracking);findViewById<Button>(R.id.searchBtn).setOnClickListener{ val id=findViewById<EditText>(R.id.orderInput).text.toString().trim().uppercase();if(id.isBlank())return@setOnClickListener;findViewById<TextView>(R.id.resultText).text="جارٍ البحث...";FirebaseFirestore.getInstance().collection("tracking").document(id).get().addOnSuccessListener{d->findViewById<TextView>(R.id.resultText).text=if(d.exists())"رقم الطلب: $id\nالحالة: ${statusAr(d.getString("status"))}" else "لم يتم العثور على الطلب"}.addOnFailureListener{findViewById<TextView>(R.id.resultText).text="تعذر البحث الآن"}}}
    private fun statusAr(s:String?)=when(s){"new"->"طلب جديد";"processing"->"قيد التجهيز";"shipped"->"تم الشحن";"delivered"->"تم التوصيل";"cancelled"->"ملغي";else->s?:"غير معروف"}
}
