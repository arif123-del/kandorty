package online.kandorty.app

import android.content.Context

object WishlistStore {
    private const val PREF = "kandorty_wishlist"
    private const val KEY = "ids"

    fun ids(context: Context): Set<String> =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getStringSet(KEY, emptySet())?.toSet() ?: emptySet()

    fun contains(context: Context, id: String): Boolean = ids(context).contains(id)

    fun toggle(context: Context, id: String): Boolean {
        val next = ids(context).toMutableSet()
        val added = if (next.contains(id)) {
            next.remove(id); false
        } else {
            next.add(id); true
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putStringSet(KEY, next).apply()
        return added
    }

    fun count(context: Context): Int = ids(context).size
}
